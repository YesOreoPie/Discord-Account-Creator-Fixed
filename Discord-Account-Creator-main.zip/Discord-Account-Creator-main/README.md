<h1 align="center"> Discord-Account-Creator </h1>

<h2 align="center">THIS VERSION IS OFFICIALLY PATCHED!! </h2>

### Check out v2 [here](https://github.com/exploitees/Cronus) (releases at ⭐️100)
or
### you can buy the unpatched version (v1) and/or the insane remake (v2) @ [skiddos.t.me](https://t.me/skiddos)

---

**A mass Discord account/token creator that can be used for:**
- Getting LVL3 Boost
- Gaining server members
- etc.

**stop asking for support yall some skids im not helping :skull:**

> **Note** ik a lot of the features in here are not implemented but its cuz i barely had time to work on it lol

> **Note** ill be working v2 for a bit of time and itll have the promised features but dont expect it right away


## Features
- Captcha SOLVER (using ai)
- Auto Joiner
- Auto Profile (makes realistic looking profile)
- Verified Email
- 0 Flags
- Auto boosts joined server (claims nitro on register)
- Online + Status (using ws connections)

---

Join my discord for more information -> https://discord.gg/HFssqAymYD

---

## Screenshots:
> **Note** **Screenshots will be updated daily/as this gen progresses || Last Updated: July 13th @ 17:30 EST**


![unknown](https://user-images.githubusercontent.com/60797067/178118009-fa3ad6fc-b4e1-4ac7-acc5-607473ffd371.png)
![unknown](https://user-images.githubusercontent.com/60797067/178118037-f7d6815f-f4da-4ba7-8fa4-12edfa2dba0e.png)
![unknown](https://user-images.githubusercontent.com/60797067/178122067-ff242557-dcef-4664-b6b3-7f0d858b38ef.png)
![unknown](https://user-images.githubusercontent.com/60797067/178123896-9511c6e6-483e-4ff6-9429-a349c17a3903.png)
![image](https://user-images.githubusercontent.com/60797067/178840065-64578920-c96d-4162-af56-b91046dc504c.png)
