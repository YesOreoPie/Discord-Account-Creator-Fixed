# hastily re-purposed from https://github.com/patrikoss/pyclick
from .humancurve import gen_mouse_move